

/*
delete from Appointment
delete from Doctor
delete from Patient
delete from Department
delete from OtherStaff
delete from LoginTable
*/

USE DBProject
GO


INSERT INTO LoginTable VALUES ('admin@clinic.com' ,'admin' ,   3) 


--DEPARTMENT INSERTION
insert into department values(1 , 'Cardiology' , 'We have the best heart specialists in town .Each one of them is very competent and experienced.')
insert into department values(2 , 'Orthopaedics' , 'Orthopedic surgeons use surgical means to treat musculoskeletal trauma, infections, tumors. We believe in the best.')
insert into department values(3 , 'Ears Nose Throat' , 'They are gentle. And are trained to handle kids as well as adults.')
insert into department values(4 , 'Physiotherapy ',' Physiotherapists work through physical therapies such as exercise, and manipulation of bones, joints and muscle tissues.' )
insert into department values(5 , 'Neurology', 'A medical speciality dealing with disorders of the nervous system. It deals with the diagnosis and treatment of all categories of disease.')



--LOGIN TABLE INSERTIION
INSERT INTO LoginTable(Email, Password, Type) VALUES('mukesh@gmail.com', 'abc', 2)
INSERT INTO LoginTable(Email, Password, Type) VALUES('john@gmail.com', 'abc', 2)
INSERT INTO LoginTable(Email, Password, Type) VALUES('kevin@gmail.com', 'abc',2)
INSERT INTO LoginTable(Email, Password, Type) VALUES('bruce@gmail.com', 'abc', 2)
INSERT INTO LoginTable(Email, Password, Type) VALUES('clark@gmail.com', 'abc', 2)
INSERT INTO LoginTable(Email, Password, Type) VALUES('ryan@gmail.com', 'abc', 2)
INSERT INTO LoginTable(Email, Password, Type) VALUES('dwayne@gmail.com', 'abc', 2)
INSERT INTO LoginTable(Email, Password, Type) VALUES('johnson@gmail.com', 'abc', 2)
INSERT INTO LoginTable(Email, Password, Type) VALUES('houdini@gmail.com', 'abc', 2)
INSERT INTO LoginTable(Email, Password, Type) VALUES('manisha@gmail.com', 'abc', 2)

INSERT INTO LoginTable(Email, Password, Type) VALUES('patient1@gmail.com', 'abc', 1)
INSERT INTO LoginTable(Email, Password, Type) VALUES('patient2@gmail.com', 'abc', 1)
INSERT INTO LoginTable(Email, Password, Type) VALUES('patient3@gmail.com', 'abc', 1)



--DOCTOR INSERTIONS
DECLARE @ID INT
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'mukesh@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'Mukesh Kumar', '156133213', 'California,USA', '4-12-1996', 'M', 1, 2500, 30000, 4, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'john@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'John', '156133213', 'illinois,USA', '12-12-1996', 'M', 1, 3000, 25000, 3.5, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'kevin@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'Kevin', '156133213', 'Windsor,Canada', '12-12-1996', 'M', 1, 1500, 20000, 5, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'bruce@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'Bruce Willis', '156133213', 'New York,USA', '05-04-1990', 'M', 1, 1000, 15000, 4.5, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'clark@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'Clark Kent', '156133213', 'Manhattan,USA', '05-04-1990', 'M', 2, 1000, 15000, 4.5, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'ryan@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'Ryan Renolds', '156133213', 'Queens,USA', '05-04-1990', 'M', 2, 1000, 15000, 4.5, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'dwayne@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'Dwayne Smith', '156133213', 'Los Angeles,USA', '05-04-1990', 'M', 3, 1000, 15000, 4.5, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'johnson@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'Alvi Johnson', '156133213', 'Las Vegas,USA', '05-04-1990', 'M', 3, 1000, 15000, 4.5, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'houdini@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'Sam Houdini', '156133213', 'Detroit,USA', '05-04-1990', 'M', 4, 1000, 15000, 4.5, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)
SELECT @ID = LoginID FROM LoginTable WHERE Email = 'manisha@gmail.com'
INSERT INTO Doctor VALUES(@ID, 'Manisha Garg', '156133213', 'Chicago,USA', '05-04-1990', 'M', 5, 1000, 15000, 4.5, 0, 'PHD IN EVERY FIELD KNOWN TO MAN', 'ENJOY', 10, 1)


--PATIENT INSERTIONS
DECLARE @P_ID INT
SELECT @P_ID = LoginID FROM LoginTable WHERE Email='patient1@gmail.com'
INSERT INTO Patient VALUES(@P_ID, 'Patient1', '61536516', 'Toronto,Canada', '4-4-1996', 'M')
SELECT @P_ID = LoginID FROM LoginTable WHERE Email='patient2@gmail.com'
INSERT INTO Patient VALUES(@P_ID, 'Patient2', '61536516', 'New York,USA', '4-4-1996', 'F')
SELECT @P_ID = LoginID FROM LoginTable WHERE Email='patient3@gmail.com'
INSERT INTO Patient VALUES(@P_ID, 'Patient3', '61536516', 'Ottawa,Canada', '4-4-1996', 'M')


select * from OtherStaff

insert into OtherStaff values ('Clara', '03227561002','Toronto,Canada', 'Nurse', 'F', '05-04-1990', 'Matric',5000)
insert into OtherStaff values ('Mary', '03227561002','Toronto,Canada', 'Nurse', 'F', '05-04-1990', 'Matric',5000)
insert into OtherStaff values ('Daisy', '03227561002','Toronto,Canada', 'Nurse', 'F', '05-04-1990', 'Matric',5000)
insert into OtherStaff values ('Elizabeth', '03227561002','Toronto,Canada', 'Nurse', 'F', '05-04-1990', 'Matric',5000)
insert into OtherStaff values ('Summer', '03227561002','Toronto,Canada', 'Reception', 'F', '05-04-1990', 'Matric',5000)
insert into OtherStaff values ('Sabrina', '03227561002','Toronto,Canada', 'Nurse', 'F', '05-04-1990', 'Matric',5000)






